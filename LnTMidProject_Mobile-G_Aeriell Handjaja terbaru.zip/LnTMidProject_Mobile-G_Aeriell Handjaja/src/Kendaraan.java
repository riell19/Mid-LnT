
public abstract class Kendaraan {
	private String jeniskendaraan;
	private String brand;
	private String nama;
	private int topSpeed;
	private int gasCap;
	private int wheel;
	private String type; 
	private int amount;
	
	public Kendaraan(String jeniskendaraan, String brand, String nama, String type, int topSpeed, int gasCap, int wheel, int amount ) {
		// TODO Auto-generated constructor stub
	this.jeniskendaraan= jeniskendaraan;
	this.brand= brand;
	this.nama= nama;
	this.type =type;
	this.topSpeed= topSpeed;
	this.gasCap= gasCap;
	this.wheel= wheel;
	this.amount= amount;
	}
public String getjeniskendaraan() {
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
