
public class Car extends Kendaraan{

	public Car() {
		// TODO Auto-generated constructor stub
	}
@Override
}
