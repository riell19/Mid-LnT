
import java.util.Vector;
import java.util.Scanner;

public class Main {

	Scanner scan = new Scanner(System.in);
	Vector<Kendaraan> kendaraan = new Vector<Kendaraan>();
	Vector<Car> car = new Vector<Car>();
	Vector<Motorcycle> motorcycle = new Vector<Motorcycle>();
	
	String jeniskendaraan,brand,nama, license, type ;
	int topSpeed, gasCap, wheel, amount ; 

		void tampilan() {
			System.out.println("PT Musang");
			System.out.println("1. Input");
			System.out.println("2. View");
			System.out.println("Choose >>");
		}
		
		public Main() {
			// TODO Auto-generated constructor stub
			int main;
			do {
				tampilan();
				switch(main) {
				case 1:
					insert();
					break;
				case 2:
					view();
					break;
				} 
			}while (main != 3);
			}
		
			private void insert() {
			do {
			System.out.print("Input type [Car | Motorcycle]:");
			jeniskendaraan = scan.nextLine();
		} while (!jeniskendaraan.equals("Car")&& !jeniskendaraan.equals("Motorcycle"));
		
		do {
			System.out.print("Input brand [>=5]:");
			brand = scan.nextLine();
		} while (brand.length()<5);		
		
		do {
		System.out.print("Input name [>=5]:");
		nama = scan.nextLine();
		} while (nama.length()<5);
		
		System.out.print("Input license:");
		license= scan.nextLine();

		do {
			System.out.print("Input top speed [100 <= topSpeed <= 250]:");
			topSpeed =scan.nextInt();
			scan.nextLine();
		} while (topSpeed <100 || topSpeed >250);
		
		do {
		System.out.print("Input gas capacity [30 <= gasCap <= 60]:");
		gasCap =scan.nextInt();
		scan.nextLine();
		} while (gasCap <30 || gasCap > 60);
		
		if (jeniskendaraan.equals("Car")) {
			do {
				System.out.print("Input wheel [4 <= wheel <=6]:");
				wheel =scan.nextInt();
				scan.nextLine();
				} while (wheel <4 || wheel >6);
				
				do {
				System.out.print("Input type [SUV | Supercar | Minivan]:");
				type =scan.nextLine();
				} while (!type.equals("SUV")&& !type.equals("Supercar")&& !type.equals("Minivan"));
				
				do {
				System.out.print("Input entertainment system amount [>= 1]:");
				amount =scan.nextInt();
				scan.nextLine();
				} while (amount <1);	
				
				System.out.print("ENTER to return");
		}
		else {
			do{
			System.out.print("Input wheel [2 <= wheel <=3]:");
			wheel =scan.nextInt();
			scan.nextLine();
			} while (wheel <2 || wheel >3);
		
			do {
				System.out.print("Input type [Automatic | Manual]:");
				type =scan.nextLine();
				} while (!type.equals("Automatic")&& !type.equals("Manual"));
			
			do {
			System.out.print("Input helm amount [>= 1]:");
			amount =scan.nextInt();
			scan.nextLine();
			} while (amount <1);
			
			System.out.print("ENTER to return");
			}}
	
	private void view() {	
		if (Kendaraan.isEmpty()) {
			System.out.println("|-----|---------------|---------------|");
			System.out.println("|No   |Type           |Name           |");
			System.out.println("|-----|---------------|---------------|");
			System.out.println("|-----|---------------|---------------|");
			sc.nextLine();
	}
		else { 
			System.out.println("|-----|---------------|---------------|");
			System.out.println("|No   |Type           |Name           |");
			System.out.println("|-----|---------------|---------------|");
			for(int i=0; i < Kendaraan.size(); i ++) {
				if (Kendaraan.get(i) instanceof Car {
				Car = (Car) Kendaraan.get(i);
					System.out.printf(null, null)f
			}
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
		
	}
}
