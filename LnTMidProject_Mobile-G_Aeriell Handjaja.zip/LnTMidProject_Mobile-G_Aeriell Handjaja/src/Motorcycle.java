
public class Motorcycle extends Kendaraan {

	public Motorcycle() {
		// TODO Auto-generated constructor stub
	}
@Override
}
